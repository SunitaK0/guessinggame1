# GUESS THE COUNT

## The Unix Workbench Project

This assignment is designed to test your facility for using 
**Git and GitHub**, 
*creating makefiles* and 
*writing Bash programs*. 


Here is the link for my project [a link](https://github.com/priyabhuvanagiri/theunixworkbench).

nano README.md
